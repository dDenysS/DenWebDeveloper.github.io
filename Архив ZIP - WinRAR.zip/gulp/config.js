module.exports = {
    root: './app',

    autoprefixerConfig: ['last 5 version', '> 1%', 'ie 8', 'ie 9','ie 11', 'Opera 12.1'],

    fileCss: 'style.scss',
    fileJs: '*'
};